class Cateogary_Model{

  String name;
  String country;
  String imgurl;
}