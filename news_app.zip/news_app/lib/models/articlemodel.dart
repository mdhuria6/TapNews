class ArticleModel
{
  String auth;
  String title;
  String description;
  String url;
  String iurl;
  String content;
  ArticleModel({this.auth,this.title,this.description,this.url,this.iurl,this.content});
}